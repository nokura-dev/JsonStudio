﻿JsonStudio 1.0.0 (Windows x64)

JsonStudio.exeを実行し、作業用フォルダを選択してください。
HTML・JavaScript・CSS・アイコンはEXEに組み込まれています。
Microsoft Edge WebView2 Runtimeが必要です（EXEには同梱していません）。
https://developer.microsoft.com/microsoft-edge/webview2/

動作確認: JSONの読み書き・自動保存・再読み込み・作成・名前変更・削除、
CSV読み込み・SQL/CSV/PNG保存・コピー・終了をWindows上で確認してください。
Macでの開発確認と生成物の検証は実施していますが、Windows実機確認は未実施です。
